import React from "react";
import {Navigate, Outlet} from "react-router-dom";

function UserRoutes({role}) {
    if (role === "" || role ===null) {
        alert("로그인한 회원만 등록이 가능합니다.")
    }
    if (role === "DEALER") {
        alert("이미 딜러로 등록되어있습니다.")
    }
    return (
        //<Outlet/> -> 내 안에 있는 컴포넌트 실행 route dom이 가지고 있음
        role === "USER" ? <Outlet/> : <Navigate to="/login"/>
    );
}

export default UserRoutes;