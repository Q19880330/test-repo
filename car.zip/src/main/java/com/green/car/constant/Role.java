package com.green.car.constant;

public enum Role {
    USER,ADMIN,DEALER
}
