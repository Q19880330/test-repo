package com.green.car.service;

import com.green.car.entity.Dealer;

public interface DealerService {
    Dealer getDealer(Long dealerId);
}
